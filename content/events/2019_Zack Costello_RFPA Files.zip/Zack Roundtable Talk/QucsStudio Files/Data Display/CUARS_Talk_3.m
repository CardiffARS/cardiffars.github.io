# Post-processing script for circuit simulation file "CUARS_Talk_3.sch"
# Plots the current and voltage waveforms at the current generator plane

freq = loadQucsVariable("CUARS_talk_3.dat", "hbfrequency");
Ics = loadQucsVariable("CUARS_talk_3.dat", "Ics.Ib");
Vcs = loadQucsVariable("CUARS_talk_3.dat", "Vcs.Vb");

padding_size = 2^10;

time = 1/freq(2);
time = time * (1e9); # Convert to ns

# ---- Calculate and plot Ics waveform ----
# FFT coefficients w/o zero padding, with negative freq values
wave_Ics_f1 = [Ics(1) rot90(Ics((2:end))/2) rot90(conj(Ics((end:-1:2)))/2)];
wave_Ics_f1 = [Ics(1) rot90(Ics((2:end))/2) zeros(1,(padding_size - length(wave_Ics_f1))) rot90(conj(Ics((end:-1:2)))/2)];

# FFT coefficients, w/ zero-centered zero padding, with negative freq values
# # of zeros is calculated to produce a power-of-two # of total values
# by subtracting the original length of testwave_v2_f1
wave_Ics_t1 = ifft(wave_Ics_f1);
# Calculate and apply scaling to zero-padded iffts w/ respect to original ifft
wave_Ics_t1 = padding_size * wave_Ics_t1;
# Double waveform (for clarity when plotting), comment out and change t to be linspace between 0 and 1 to have just one cycle
wave_Ics_t1 = [wave_Ics_t1 wave_Ics_t1];

# Plot waveform
t = linspace(0,2*time,length(wave_Ics_t1));
figure(1);
plot(t,wave_Ics_t1,'b');
xlabel('Time (ns)');
ylabel('Current (A)');

# ---- Calculate and plot Vcs waveform ----
# FFT coefficients w/o zero padding, with negative freq values
wave_Vcs_f1 = [Vcs(1) rot90(Vcs((2:end))/2) rot90(conj(Vcs((end:-1:2)))/2)];
wave_Vcs_f1 = [Vcs(1) rot90(Vcs((2:end))/2) zeros(1,(padding_size - length(wave_Vcs_f1))) rot90(conj(Vcs((end:-1:2)))/2)];

# FFT coefficients, w/ zero-centered zero padding, with negative freq values
# # of zeros is calculated to produce a power-of-two # of total values
# by subtracting the original length of testwave_v2_f1
wave_Vcs_t1 = ifft(wave_Vcs_f1);
# Calculate and apply scaling to zero-padded iffts w/ respect to original ifft
wave_Vcs_t1 = padding_size * wave_Vcs_t1;
# Double waveform (for clarity when plotting), comment out and change t to be linspace between 0 and 1 to have just one cycle
wave_Vcs_t1 = [wave_Vcs_t1 wave_Vcs_t1];

# Plot both waveforms
t = linspace(0,2*time,length(wave_Vcs_t1));
figure(2);
plot(t,wave_Vcs_t1,'r');
xlabel('Time (ns)');
ylabel('Voltage (V)');

figure(3);
[ax h1 h2] = plotyy(t,wave_Vcs_t1,t,wave_Ics_t1);
set(ax,{'ycolor'},{'r';'b'});
set(h1,'Color',"r");
set(h2,'Color',"b");
xlabel('Time (ns)');
set(ax,{'ylabel'},{'Voltage (V)';'Current (A)'});
# ylabel(ax(1),'Voltage (V)');
# ylabel(ax(2),'Current (A)');